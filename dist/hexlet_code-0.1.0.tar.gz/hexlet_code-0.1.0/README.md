### Hexlet tests and linter status:
[![Actions Status](https://github.com/Boison88/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Boison88/python-project-49/actions)

<a href="https://codeclimate.com/github/Boison88/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f991ad98e5296b448aef/maintainability" /></a>

BRAIN-EVEN
<a href="https://asciinema.org/a/538165" target="_blank"><img src="https://asciinema.org/a/538165.svg" /></a>

BRAIN-CALC
<a href="https://asciinema.org/a/538167" target="_blank"><img src="https://asciinema.org/a/538167.svg" /></a>

BRAIN-GCD
<a href="https://asciinema.org/a/538168" target="_blank"><img src="https://asciinema.org/a/538168.svg" /></a>

BRAIN-PROGRESSION
<a href="https://asciinema.org/a/538175" target="_blank"><img src="https://asciinema.org/a/538175.svg" /></a>

BRAIN-PRIME:
<a href="https://asciinema.org/a/538179" target="_blank"><img src="https://asciinema.org/a/538179.svg" /></a>
