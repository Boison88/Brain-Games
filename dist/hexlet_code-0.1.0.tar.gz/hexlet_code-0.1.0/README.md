### Hexlet tests and linter status:
[![Actions Status](https://github.com/Boison88/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Boison88/python-project-49/actions)

<a href="https://codeclimate.com/github/Boison88/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f991ad98e5296b448aef/maintainability" /></a>
