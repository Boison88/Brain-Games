# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Boison88/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Boison88/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/Boison88/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f991ad98e5296b448aef/maintainability" /></a>\n\nBRAIN-EVEN\n\n<a href="https://asciinema.org/a/538165" target="_blank"><img src="https://asciinema.org/a/538165.svg" /></a>\n\n\nBRAIN-CALC\n\n<a href="https://asciinema.org/a/538167" target="_blank"><img src="https://asciinema.org/a/538167.svg" /></a>\n\n\nBRAIN-GCD\n\n<a href="https://asciinema.org/a/538168" target="_blank"><img src="https://asciinema.org/a/538168.svg" /></a>\n\n\nBRAIN-PROGRESSION\n\n<a href="https://asciinema.org/a/538175" target="_blank"><img src="https://asciinema.org/a/538175.svg" /></a>\n\n\nBRAIN-PRIME\n\n<a href="https://asciinema.org/a/538179" target="_blank"><img src="https://asciinema.org/a/538179.svg" /></a>\n',
    'author': 'boison88',
    'author_email': 'boison88@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
